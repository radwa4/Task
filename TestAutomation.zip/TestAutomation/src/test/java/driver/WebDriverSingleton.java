package driver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
public class WebDriverSingleton {

    private static WebDriver webDriver;
    private static WebDriverSingleton webDriverSingleton = null;
    private static String driverType = "webdriver.chrome.driver";
    private static String chromeDriverPath =  System.getProperty("user.dir")+"/src/driverbinary/chromedriver.exe";
    //private static String chromeDriverPath = "D:/rebasemaster/cvm_alltribe/vftestingautomationframework/driver_binaries/chromedriver.exe";

    private WebDriverSingleton() {
        setDriverCapabilities();
    }
    public static WebDriverSingleton getDriverSingleton() {
        if (webDriverSingleton == null)
            webDriverSingleton = new WebDriverSingleton();
        return webDriverSingleton; }

    private void setDriverCapabilities(){
        System.setProperty(driverType, chromeDriverPath);

        ChromeOptions chromeCapabilities = new ChromeOptions();

        webDriver = new ChromeDriver();
    }
    public static WebDriver getWebDriver(){ return webDriver;}

    public void navigateTo(String link){
        webDriver.navigate().to(link);
    }

    public void resetCache() throws InterruptedException {
        webDriver.manage().deleteAllCookies();
        //TODO: remove thread.sleep
        Thread.sleep(7000);
    }

    public static void close(){
        webDriver.quit();
    }


}
