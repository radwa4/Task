package Pages;

import driver.WebDriverSingleton;
import screens.BasePage;
import screens.HomePage;

public class VodBrowser extends BasePage {
    private final WebDriverSingleton webDriverSingleton = WebDriverSingleton.getDriverSingleton();
    public HomePage homePage ;
    public VodBrowser() {homePage = new HomePage();}
}
