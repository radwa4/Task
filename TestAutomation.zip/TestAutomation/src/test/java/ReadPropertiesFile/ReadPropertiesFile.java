package ReadPropertiesFile;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadPropertiesFile {
    private static final String BrowserNamePath=System.getProperty("user.dir")+"/src/main/resources/config/Browser.properties";
    private static final String URlPath=System.getProperty("user.dir")+"/src/main/resources/config/URL.properties";
    private static final String filePath=System.getProperty("user.dir")+"/src/main/resources/config/filepath.properties";


    public static Properties setBrowser() throws IOException {
        Properties configProperties = new Properties();
        FileInputStream inputStream = new FileInputStream(BrowserNamePath);
        configProperties.load(inputStream);
        return configProperties;
    }

    public static Properties setUrl() throws IOException {
        Properties configProperties = new Properties();
        FileInputStream inputStream = new FileInputStream(URlPath);
        configProperties.load(inputStream);
        return configProperties;
    }


    public static Properties setfilepath() throws IOException {
        Properties configProperties = new Properties();
        FileInputStream inputStream = new FileInputStream(filePath);
        configProperties.load(inputStream);
        return configProperties;
    }

}
