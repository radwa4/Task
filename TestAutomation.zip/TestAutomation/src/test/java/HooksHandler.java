import driver.WebDriverSingleton;

import java.io.IOException;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import tests.BaseTest;


public class HooksHandler extends BaseTest {
    @Before(value = "@vod", order = 1)
    public void setUpvodafone() throws InterruptedException, IOException {
        chromeDriver = WebDriverSingleton.getDriverSingleton();
        chromeDriver.resetCache();
        chromeDriver.navigateTo(readUrl());

    }

    @After(value = "@vod")
    public void tearDownvodafone() throws InterruptedException {
        chromeDriver.resetCache();
        closeWebDriverAfterAllTestsHook();
    }

    private void closeWebDriverAfterAllTestsHook() {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            WebDriverSingleton.close();
        }));
    }





}