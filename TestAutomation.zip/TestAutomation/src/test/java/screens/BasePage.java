package screens;

import driver.WebDriverSingleton;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.time.Duration;

public class BasePage {

    WebDriver chromeDriver = WebDriverSingleton.getWebDriver();
    final int waitTime = 35;

    public BasePage(){
        PageFactory.initElements(new AppiumFieldDecorator(chromeDriver, Duration.ofSeconds(waitTime)), this);
    }

}
