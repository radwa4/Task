package screens;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import screens.BasePage;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class HomePage  extends BasePage {
    @FindBy(xpath = "//*[@href='https://careers.vodafone.com/']")
    private WebElement CareerButton;
    @FindBy(id="onetrust-accept-btn-handler")
            private WebElement AcceptCookiesButton;

@FindBy(xpath = "//span[contains(text(),'Apply')]")
private WebElement ApplyButton;

    @FindBy(xpath = "//strong[contains(text(),'Apply')]")
    private WebElement GotoApplyButton;
@FindBy(xpath = "//*[@id='career-workflow']/div/div/div[2]/div/div/div/div[2]/div[2]/div/div/div/div/div/a")
private WebElement UploadCVButton;

@FindBy(className = "privacy-content")
private WebElement privacycontent;


@FindBy(xpath ="//*[href='https://web.vodafone.com.eg/spa/myHome']")
private WebElement ManagerAccountButton;

@FindBy(id= "goToRestPassword")
private WebElement ResetButton;

@FindBy(id = "username")
private WebElement mobileField;

@FindBy(id= "input-mobile-trigger")
private WebElement SendButton;

@FindBy(className = "alert-text")
private  WebElement Alert;


    public void clickOnButton(){
        CareerButton.click(); }
    public void Acceptcookies(){
        chromeDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        AcceptCookiesButton.click(); }
    public void clickOnGOtoApplyButton() throws InterruptedException {
        chromeDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        GotoApplyButton.click();
        ArrayList<String> newTb = new ArrayList<String>(chromeDriver.getWindowHandles());
        //switch to new tab
        chromeDriver.switchTo().window(newTb.get(1));
    }
    public void SwitchTonewTab(){
        WebDriverWait wait = new WebDriverWait(chromeDriver,30);
        wait.until(ExpectedConditions.elementToBeClickable(AcceptCookiesButton));
//                        UploadCVButton.sendKeys("D:\\MY PC\\my files");


    }

     public  void Scroll(){
         JavascriptExecutor js = (JavascriptExecutor) chromeDriver;
         js.executeScript("scroll(0, 1000);");

     };

    public void doubleClicK() throws InterruptedException {
        Thread.sleep(1000);
        Actions act = new Actions(chromeDriver);
        act.doubleClick(ApplyButton).build().perform();
        Thread.sleep(1000);

    }

    public void uploadCv(){
        WebDriverWait wait = new WebDriverWait(chromeDriver,30);
        wait.until(ExpectedConditions.elementToBeClickable(UploadCVButton));
        Actions act = new Actions(chromeDriver);
        act.doubleClick(UploadCVButton).build().perform();
        chromeDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        UploadCVButton.click();

    }


        public void uploadFileWithRobot (String filePath){
            StringSelection stringSelection = new StringSelection(filePath);
            Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
            clipboard.setContents(stringSelection, null);
            Robot robot = null;
            try {
                robot = new Robot();
            } catch (AWTException e) {
                e.printStackTrace();
            }
            robot.delay(250);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.delay(300);
            robot.keyRelease(KeyEvent.VK_ENTER);
        }


public void waitupload(){
    WebDriverWait wait = new WebDriverWait(chromeDriver,40);
    wait.until(ExpectedConditions.elementToBeClickable(privacycontent));
}

    public void clickOnManagerButton(){
        ManagerAccountButton.click();
        WebDriverWait wait = new WebDriverWait(chromeDriver,30);
        wait.until(ExpectedConditions.elementToBeClickable(ResetButton));}

    public void clickOnRestButton(){
        ResetButton.click();
        WebDriverWait wait = new WebDriverWait(chromeDriver,30);
        wait.until(ExpectedConditions.elementToBeClickable(mobileField));}


        public void setmsisdn(String msisdn){
    mobileField.sendKeys(System.getProperty(msisdn));
        }


    public void clickOnSendButton(){
        SendButton.click();}

        public WebElement validatealartmessage(){
        return Alert;
        }



}