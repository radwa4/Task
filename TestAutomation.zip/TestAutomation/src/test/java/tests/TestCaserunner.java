package tests;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = { "src/test/java/tests/Testcase1.feature","src/test/java/tests/Testcase2.feature"},
        glue={"tests.TestCase1.MyStepdefs","tests.TestCase2.MyStepdefs2"},
        plugin = { "pretty", "html:reports/TestCase.html"},
        monochrome = true
)


    public class TestCaserunner extends AbstractTestNGCucumberTests {


}
