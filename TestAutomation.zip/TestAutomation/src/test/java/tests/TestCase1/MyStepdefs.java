package tests.TestCase1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import tests.BaseTest;

import java.io.IOException;

public class MyStepdefs extends BaseTest {
    @Given("open Vodafone Website")
    public void openVodafoneWebsite() {
    }

    @Given("scroll down")
    public void scrollDown() {
         browser.homePage.Scroll();

    }

    @And("click on CareerButton")
    public void clickOnCareerButton() {

        browser.homePage.clickOnButton();
    }

    @And("Accept cookies pop up")
    public void acceptCookiesPopUp() {
browser.homePage.Acceptcookies();
    }

    @And("click on Apply Button")
    public void clickOnApplyButton() throws InterruptedException {
        browser.homePage.doubleClicK();
    }

    @And("click on GO To Apply Button")
    public void clickOnGOToApplyButton() throws InterruptedException {
        browser.homePage.clickOnGOtoApplyButton();
    }

    @When("click on Upload CV")
    public void clickOnUploadCV() {
        browser.homePage.SwitchTonewTab();
        browser.homePage.Acceptcookies();

    }

    @And("Upload Cv")
    public void uploadCv() {
        browser.homePage.Scroll();
        browser.homePage.uploadCv();


    }


    @Then("Assert Cv upload Successfully")
    public void assertCvUploadSuccessfully() throws IOException {
        browser.homePage.uploadFileWithRobot(System.getProperty("user.dir")+"/"+readpathfile());
browser.homePage.waitupload();
    }


}
