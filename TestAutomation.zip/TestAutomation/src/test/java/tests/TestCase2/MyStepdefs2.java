package tests.TestCase2;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;
import tests.BaseTest;

public class MyStepdefs2 extends BaseTest {

   @Given("click on ManageAccount")
   public void clickOnManageAccount() {
    browser.homePage.clickOnManagerButton();
   }

    @And("Click on resetPassword")
    public void clickOnResetPassword() {
       browser.homePage.clickOnRestButton();
    }

    @When("Enter <invalidMsisdn>")
    public void enterInvalidMsisdn(String invalidMsisdn) {
       browser.homePage.setmsisdn(invalidMsisdn);
    }

    @And("click on Send button")
    public void clickOnSendButton() {
       browser.homePage.clickOnSendButton();
    }

    @Then("Validate<alertmessage>")
    public void validateAlertmessage(String alertmessage) {
        Assert.assertEquals(alertmessage,browser.homePage.validatealartmessage().getText());
    }
}

