package tests;

import Pages.VodBrowser;
import ReadPropertiesFile.ReadPropertiesFile;
import screens.BasePage;
import driver.WebDriverSingleton;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Properties;

public class BaseTest extends ReadPropertiesFile {

    protected WebDriverSingleton chromeDriver;
    public static VodBrowser browser = new VodBrowser();


    public BaseTest(){
        chromeDriver = WebDriverSingleton.getDriverSingleton();
    }


    public String readUrl() throws IOException {

        String UrlName;
        Properties Url;
        Url= ReadPropertiesFile.setUrl();
        UrlName=Url.getProperty("UrlName");

        return UrlName;}



    public String readpathfile() throws IOException {

        String pathfileName;

        Properties pathfile;
     pathfile= ReadPropertiesFile.setfilepath();
      pathfileName=pathfile.getProperty("fileName");

        return pathfileName;}

}
