package apiProject;

import io.restassured.RestAssured;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;


public class TRELLORESTAPIsusingRestAssured {



   public static String BaseUrl = "https://jsonplaceholder.typicode.com";
    public static void main(String[] args) {

        GetAllLposts();
        GetpostbyID();
        creatpost();


    }
    public static void GetAllLposts(){
        Response response = RestAssured.given().baseUri(BaseUrl+"posts").when().get();
        Assert.assertEquals(response.getStatusCode() , 200);
        String Status = response.xmlPath().getString("ResponseModel.userId");
        System.out.println(Status);
        Assert.assertEquals(Status , "1");

    }

    public static void GetpostbyID(){
        Response response = RestAssured.given().baseUri(BaseUrl+"posts/1").when().get();
        Assert.assertEquals(response.getStatusCode() , 200);
        String Status = response.xmlPath().getString("ResponseModel.userId");
        System.out.println(Status);
        Assert.assertEquals(Status , "1");

    }
    public static void creatpost(){
        Response response = RestAssured.given().baseUri(BaseUrl+"/posts/1").queryParam("title","foo")
                .queryParam("body", "bar").queryParam("userId", "1").when().post();
        Assert.assertEquals(response.getStatusCode() , 200);

    }






}